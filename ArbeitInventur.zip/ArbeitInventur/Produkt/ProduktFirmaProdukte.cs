﻿namespace ArbeitInventur
{
    public class ProduktFirmaProdukte
    {
        public string Kategorie { get; set; }
        public string Beschreibung { get; set; }
        public int Menge { get; set; }
        public int Mindestbestand { get; set; }
    }
}